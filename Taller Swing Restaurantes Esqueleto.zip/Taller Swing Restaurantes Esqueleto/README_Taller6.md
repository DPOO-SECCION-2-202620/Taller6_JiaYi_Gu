# Taller 6 -- GUIs con Swing y Java2D

## Descripción

Aplicación de escritorio desarrollada en Java Swing para llevar un
diario de restaurantes. Permite registrar restaurantes, consultar sus
datos, indicar si ya fueron visitados y visualizar sus ubicaciones sobre
un mapa.

## Funcionalidades

-   Mostrar la lista de restaurantes registrados.
-   Consultar el nombre, la calificación y el estado de visita del
    restaurante seleccionado.
-   Registrar un restaurante nuevo con nombre, calificación de 1 a 5,
    estado de visita y ubicación en el mapa.
-   Visualizar todos los restaurantes en el mapa.
-   Filtrar el mapa para mostrar únicamente los restaurantes visitados.

## Organización del proyecto

El código fuente se encuentra en `src`, organizado en los siguientes
paquetes:

-   `uniandes.dpoo.swing.mundo`: clases `Diario` y `Restaurante`, que
    representan la información del dominio.
-   `uniandes.dpoo.swing.interfaz.principal`: ventana principal y
    paneles de lista, detalles y botones.
-   `uniandes.dpoo.swing.interfaz.agregar`: ventana y paneles para
    registrar restaurantes.
-   `uniandes.dpoo.swing.interfaz.mapa`: ventana y panel para visualizar
    los restaurantes en el mapa.

La carpeta `imagenes` contiene `mapa.png` y las imágenes `stars1.png` a
`stars5.png`, utilizadas por la interfaz.

## Requisitos

-   Java JDK instalado.
-   Eclipse IDE con soporte para proyectos Java.

## Cómo importar y ejecutar en Eclipse

1.  Descomprimir la carpeta del proyecto.
2.  En Eclipse, seleccionar **File → Import → General → Existing
    Projects into Workspace**.
3.  Seleccionar **Select root directory** y elegir la carpeta del
    proyecto que contiene los archivos `.project` y `.classpath`, además
    de las carpetas `src` e `imagenes`.
4.  Finalizar la importación.
5.  En el explorador de proyectos, abrir
    `src/uniandes/dpoo/swing/interfaz/principal/VentanaPrincipal.java`.
6.  Hacer clic derecho sobre el archivo y seleccionar **Run As → Java
    Application**.

La aplicación inicia con algunos restaurantes de ejemplo cargados desde
el método `main` de `VentanaPrincipal`.

## Uso básico

-   **Nuevo:** abre el formulario para ingresar el nombre, la
    calificación y el estado de visita. Después se marca la ubicación
    haciendo clic sobre el mapa y se selecciona **Crear**.
-   **Ver todos:** abre el mapa con los restaurantes registrados.
-   **Todos / Visitados:** permite cambiar entre la visualización de
    todos los restaurantes y la de aquellos marcados como visitados.
-   **Lista principal:** al seleccionar un restaurante se actualizan sus
    detalles en la ventana principal.

## Diagrama de clases

La entrega incluye el diagrama de clases de la aplicación en formato PNG
y el archivo editable de draw.io.
